export interface Question {
  id: string;
  text: string;
  options: string[]; // Should always be 4 options
  correctIndex: number;
  subject?: string; // e.g., "Toán", "Tiếng Việt", "Khoa Học"
  grade?: string;   // e.g., "Lớp 1", "Lớp 2", "Mầm Non"
}

export interface Prize {
  id: string;
  name: string;
  image: string; // URL or emoji
}

export type GameState = 'welcome' | 'selection' | 'question' | 'tearing' | 'reward' | 'admin';

export enum BagColor {
  PINK = 'pink',
  BLUE = 'blue',
  YELLOW = 'yellow',
  GREEN = 'green',
}

export const SUBJECTS = ['Tin Học'];
export const GRADES = ['Lớp 3', 'Lớp 4', 'Lớp 5'];

export interface GameFilter {
  subject: string; // 'All' or specific subject
  grade: string;   // 'All' or specific grade
}