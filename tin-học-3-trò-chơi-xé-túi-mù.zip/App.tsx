import React, { useState, useEffect, useRef } from 'react';
import { GameState, Question, BagColor, Prize, GameFilter } from './types';
import { AdminPanel } from './components/AdminPanel';
import { BlindBagIcon, FlowerIcon, SparkleIcon } from './components/Icons';
import { Settings, Volume2, VolumeX, ArrowLeft, RefreshCcw, HelpCircle, X, Gift, MessageCircleQuestion, MousePointerClick } from 'lucide-react';
import confetti from 'canvas-confetti';

// --- INITIAL DATA ---
const DEFAULT_QUESTIONS: Question[] = [
  // Lớp 3
  {
    id: '1',
    text: 'Máy tính để bàn thường có mấy bộ phận cơ bản?',
    options: ['2 bộ phận', '3 bộ phận', '4 bộ phận', '5 bộ phận'],
    correctIndex: 2,
    subject: 'Tin Học',
    grade: 'Lớp 3'
  },
  {
    id: '2',
    text: 'Bộ phận nào của máy tính được ví như "bộ não" điều khiển mọi hoạt động?',
    options: ['Màn hình', 'Thân máy (CPU)', 'Bàn phím', 'Chuột'],
    correctIndex: 1,
    subject: 'Tin Học',
    grade: 'Lớp 3'
  },
  {
    id: '3',
    text: 'Hai phím có gai trên hàng phím cơ sở dùng để làm mốc đặt tay là:',
    options: ['A và S', 'F và J', 'G và H', 'K và L'],
    correctIndex: 1,
    subject: 'Tin Học',
    grade: 'Lớp 3'
  },
  // Lớp 4
  {
    id: '4',
    text: 'Phần mềm nào sau đây dùng để soạn thảo văn bản?',
    options: ['Paint', 'Microsoft Word', 'Google Chrome', 'Windows'],
    correctIndex: 1,
    subject: 'Tin Học',
    grade: 'Lớp 4'
  },
  {
    id: '5',
    text: 'Để lưu một tệp văn bản mới, em sử dụng tổ hợp phím nào?',
    options: ['Ctrl + C', 'Ctrl + V', 'Ctrl + S', 'Ctrl + P'],
    correctIndex: 2,
    subject: 'Tin Học',
    grade: 'Lớp 4'
  },
  {
    id: '6',
    text: 'Thư mục có thể chứa những gì?',
    options: ['Chỉ chứa tệp', 'Chỉ chứa thư mục con', 'Chứa tệp và thư mục con', 'Không chứa gì cả'],
    correctIndex: 2,
    subject: 'Tin Học',
    grade: 'Lớp 4'
  },
  // Lớp 5
  {
    id: '7',
    text: 'Phần mềm MS PowerPoint dùng để làm gì?',
    options: ['Soạn thảo văn bản', 'Vẽ tranh', 'Thiết kế bài trình chiếu', 'Tính toán'],
    correctIndex: 2,
    subject: 'Tin Học',
    grade: 'Lớp 5'
  },
  {
    id: '8',
    text: 'Để thêm một trang chiếu mới trong PowerPoint, em chọn nút lệnh nào?',
    options: ['New Slide', 'Layout', 'Design', 'Transitions'],
    correctIndex: 0,
    subject: 'Tin Học',
    grade: 'Lớp 5'
  },
  {
    id: '9',
    text: 'Mạng Internet mang lại lợi ích gì?',
    options: ['Tìm kiếm thông tin', 'Liên lạc với bạn bè', 'Học tập và giải trí', 'Tất cả các ý trên'],
    correctIndex: 3,
    subject: 'Tin Học',
    grade: 'Lớp 5'
  },
  {
    id: '10',
    text: 'Khi nhận được một email từ người lạ có đính kèm tệp, em nên làm gì?',
    options: ['Mở tệp ra xem ngay', 'Chuyển tiếp cho bạn bè', 'Không mở và hỏi ý kiến người lớn', 'Tải tệp về máy tính'],
    correctIndex: 2,
    subject: 'Tin Học',
    grade: 'Lớp 5'
  }
];

const PRIZES: Prize[] = [
  { id: 'p1', name: 'Gấu Bông Cute', image: '🧸' },
  { id: 'p2', name: 'Kẹo Ngọt', image: '🍬' },
  { id: 'p3', name: 'Ngôi Sao May Mắn', image: '🌟' },
  { id: 'p4', name: 'Mèo Thần Tài', image: '🐱' },
  { id: 'p5', name: 'Bánh Donut', image: '🍩' },
  { id: 'p6', name: 'Trái Tim', image: '💖' },
];

const DEFAULT_BGM_URL = "https://cdn.pixabay.com/audio/2022/10/25/audio_2d005f0119.mp3";

const BASE_COLORS = [
  BagColor.PINK, BagColor.BLUE, BagColor.GREEN, BagColor.YELLOW
];

const App: React.FC = () => {
  // State
  const [gameState, setGameState] = useState<GameState>('welcome');
  const [questions, setQuestions] = useState<Question[]>(DEFAULT_QUESTIONS);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [currentPrize, setCurrentPrize] = useState<Prize | null>(null);
  const [showAdmin, setShowAdmin] = useState(false);
  const [showInstructions, setShowInstructions] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.3);
  const [bagAnimation, setBagAnimation] = useState(false);
  
  // Game Configuration State
  const [bagCount, setBagCount] = useState<number>(() => {
    return parseInt(localStorage.getItem('blind_bag_count') || '8', 10);
  });

  const [gameFilter, setGameFilter] = useState<GameFilter>(() => {
    const saved = localStorage.getItem('blind_bag_filter');
    return saved ? JSON.parse(saved) : { subject: 'All', grade: 'All' };
  });
  
  // BGM State
  const [bgmSource, setBgmSource] = useState<string>(() => {
    return localStorage.getItem('blind_bag_bgm') || DEFAULT_BGM_URL;
  });
  
  // New State for tracking opened bags
  const [openedIndices, setOpenedIndices] = useState<number[]>([]);
  const [currentBagIndex, setCurrentBagIndex] = useState<number | null>(null);
  
  // State for shaking animation on click
  const [shakingBagIndex, setShakingBagIndex] = useState<number | null>(null);

  // 3D Flip Effect State
  const [flipDirection, setFlipDirection] = useState<'left' | 'right' | 'up' | 'down'>(() => {
    return (localStorage.getItem('blind_bag_flip_dir') as any) || 'left';
  });
  const [rotationAngle, setRotationAngle] = useState<number>(() => {
    return parseInt(localStorage.getItem('blind_bag_flip_angle') || '15', 10);
  });

  // Audio Refs
  const bgmRef = useRef<HTMLAudioElement | null>(null);

  // Derive bag colors based on count
  const bagColors = React.useMemo(() => {
    return Array.from({ length: bagCount }, (_, i) => BASE_COLORS[i % BASE_COLORS.length]);
  }, [bagCount]);

  // Initialize and Update Background Music Player
  useEffect(() => {
    // Clean up previous audio
    if (bgmRef.current) {
      bgmRef.current.pause();
      bgmRef.current.src = "";
    }

    // Initialize new audio
    bgmRef.current = new Audio(bgmSource);
    bgmRef.current.loop = true;
    bgmRef.current.volume = volume;
    bgmRef.current.muted = isMuted;

    // Play if allowed and not muted
    if (!isMuted && gameState !== 'welcome') {
      bgmRef.current.play().catch(e => console.log("Audio play failed (autoplay policy):", e));
    }

    return () => {
      if (bgmRef.current) {
        bgmRef.current.pause();
        bgmRef.current = null;
      }
    };
  }, [bgmSource]); // Re-run whenever bgmSource changes

  // Handle Mute Toggle (Sync with Ref)
  useEffect(() => {
    if (bgmRef.current) {
      bgmRef.current.muted = isMuted;
      // If unmuting and game is active, ensure it plays
      if (!isMuted && bgmRef.current.paused && gameState !== 'welcome') {
         bgmRef.current.play().catch(e => console.log("Resume failed:", e));
      }
    }
  }, [isMuted, gameState]);

  // Handle Volume Change
  useEffect(() => {
    if (bgmRef.current) {
      bgmRef.current.volume = volume;
    }
  }, [volume]);

  // Load Questions from LocalStorage
  useEffect(() => {
    const saved = localStorage.getItem('blind_bag_questions_v3');
    if (saved) {
      try {
        setQuestions(JSON.parse(saved));
      } catch (e) {
        console.error("Error loading questions", e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('blind_bag_questions_v3', JSON.stringify(questions));
  }, [questions]);

  // Save settings to local storage
  useEffect(() => {
    localStorage.setItem('blind_bag_count', bagCount.toString());
  }, [bagCount]);

  useEffect(() => {
    localStorage.setItem('blind_bag_filter', JSON.stringify(gameFilter));
  }, [gameFilter]);

  useEffect(() => {
    localStorage.setItem('blind_bag_flip_dir', flipDirection);
  }, [flipDirection]);

  useEffect(() => {
    localStorage.setItem('blind_bag_flip_angle', rotationAngle.toString());
  }, [rotationAngle]);

  const playSound = (type: 'click' | 'correct' | 'wrong' | 'win') => {
    if (isMuted) return;
  };

  // --- HANDLERS ---

  const handleUpdateBgm = (newUrl: string | null) => {
    if (newUrl) {
      try {
        localStorage.setItem('blind_bag_bgm', newUrl);
        setBgmSource(newUrl);
      } catch (e) {
        console.error("Storage limit exceeded", e);
        alert("Không thể lưu file nhạc do giới hạn bộ nhớ trình duyệt. Vui lòng chọn file nhỏ hơn.");
      }
    } else {
      // Reset to default
      localStorage.removeItem('blind_bag_bgm');
      setBgmSource(DEFAULT_BGM_URL);
    }
  };
  
  const handleUpdateBagCount = (newCount: number) => {
    setBagCount(newCount);
    // Reset opened state if count changes to avoid index issues
    setOpenedIndices([]);
    setCurrentBagIndex(null);
  };

  const handleStartGame = () => {
    playSound('click');
    if (bgmRef.current && bgmRef.current.paused && !isMuted) {
      bgmRef.current.play().catch(e => console.log("Audio play failed (autoplay policy):", e));
    }
    // Change: Open Admin Panel instead of starting game
    setShowAdmin(true);
  };
  
  const handleStartGameFromAdmin = () => {
    playSound('click');
    setShowAdmin(false);
    setGameState('selection');
  };

  const getFilteredQuestions = () => {
    return questions.filter(q => {
      const matchSubject = gameFilter.subject === 'All' || q.subject === gameFilter.subject;
      const matchGrade = gameFilter.grade === 'All' || q.grade === gameFilter.grade;
      return matchSubject && matchGrade;
    });
  };

  const handleBagClick = (index: number) => {
    // 1. Play sound
    playSound('click');
    
    // 2. Trigger shake animation
    setShakingBagIndex(index);

    // 3. Wait for animation to finish before changing state
    setTimeout(() => {
        setShakingBagIndex(null);
        setCurrentBagIndex(index);
        
        // Filter questions based on current game settings
        const availableQuestions = getFilteredQuestions();
        
        // Fallback if no questions match filter
        const pool = availableQuestions.length > 0 ? availableQuestions : questions;
        
        const randomQ = pool[Math.floor(Math.random() * pool.length)];
        setCurrentQuestion(randomQ);
        setSelectedAnswer(null);
        setIsCorrect(null);
        setGameState('question');
    }, 500); // 500ms matches the shake-hard animation duration
  };

  const handleAnswer = (index: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(index);
    
    if (currentQuestion && index === currentQuestion.correctIndex) {
      playSound('correct');
      setIsCorrect(true);
      setTimeout(() => {
        setGameState('tearing');
        startTearingSequence();
      }, 1500);
    } else {
      playSound('wrong');
      setIsCorrect(false);
    }
  };

  const startTearingSequence = () => {
    setBagAnimation(true);
    setTimeout(() => {
      const randomPrize = PRIZES[Math.floor(Math.random() * PRIZES.length)];
      setCurrentPrize(randomPrize);
      setBagAnimation(false);
      setGameState('reward');
      playSound('win');
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FFC4D6', '#AEE2FF', '#FFF4B5', '#B5F1CC']
      });
    }, 2000);
  };

  const handleNextTurn = () => {
    // When clicking "Open Another Bag"
    playSound('click');
    
    // Mark the current bag as opened so it disappears
    if (currentBagIndex !== null) {
      setOpenedIndices(prev => [...prev, currentBagIndex]);
    }
    
    // Reset temporary states
    setCurrentBagIndex(null);
    setCurrentQuestion(null);
    setSelectedAnswer(null);
    setIsCorrect(null);
    setCurrentPrize(null);
    
    setGameState('selection');
  };

  const handleReset = () => {
    // Complete reset
    setGameState('welcome');
    setCurrentQuestion(null);
    setSelectedAnswer(null);
    setIsCorrect(null);
    setCurrentPrize(null);
    setOpenedIndices([]); // Reset opened bags
    setCurrentBagIndex(null);
  };

  const handleRetryQuestion = () => {
    setSelectedAnswer(null);
    setIsCorrect(null);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  // --- COMPONENTS FOR LAYOUT ---
  
  const Decorations = () => (
    <>
      <FlowerIcon className="absolute top-4 left-4 w-16 h-16 animate-spin-slow" color="#FF6B6B" />
      <FlowerIcon className="absolute top-12 left-24 w-10 h-10 animate-spin-slow" style={{animationDuration: '10s'}} color="#FF9EAA" />
      
      <FlowerIcon className="absolute bottom-4 left-8 w-20 h-20 animate-spin-slow" style={{animationDirection: 'reverse'}} color="#FFC4D6" />
      
      <FlowerIcon className="absolute top-8 right-8 w-14 h-14 animate-spin-slow" color="#FF9EBB" />
      
      <SparkleIcon className="absolute top-20 right-20 w-8 h-8 animate-pulse" />
      <SparkleIcon className="absolute bottom-10 right-10 w-12 h-12 animate-pulse" style={{animationDelay: '0.5s'}} />
      <SparkleIcon className="absolute bottom-32 left-10 w-6 h-6 animate-pulse" style={{animationDelay: '1s'}} />
    </>
  );

  const getFlipTransform = () => {
    switch (flipDirection) {
      case 'left': return `rotateY(-${rotationAngle}deg)`;
      case 'right': return `rotateY(${rotationAngle}deg)`;
      case 'up': return `rotateX(${rotationAngle}deg)`;
      case 'down': return `rotateX(-${rotationAngle}deg)`;
      default: return `rotateY(-${rotationAngle}deg)`;
    }
  };

  return (
    <div className="min-h-screen w-full font-rounded text-gray-700 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <style>
        {`
          .hover-3d-flip:hover {
            transform: perspective(1000px) ${getFlipTransform()} scale(1.1) !important;
            z-index: 10 !important;
            filter: drop-shadow(0 10px 15px rgba(0,0,0,0.15)) !important;
          }
        `}
      </style>
      <Decorations />

      {/* Control Bar */}
      <div className="absolute top-4 right-4 flex gap-2 z-40 items-center flex-wrap justify-end">
        {/* Volume Control Group */}
        <div className="flex items-center gap-2 bg-white p-2 rounded-full shadow-md border-2 border-cute-pink transition-all">
          <button onClick={toggleMute} className="text-cute-pink hover:scale-110 transition active:scale-95 transform">
            {isMuted || volume === 0 ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>
          <input 
            type="range" 
            min="0" 
            max="1" 
            step="0.1" 
            value={isMuted ? 0 : volume}
            onChange={(e) => {
              const v = parseFloat(e.target.value);
              setVolume(v);
              if (v > 0 && isMuted) setIsMuted(false);
            }}
            className="w-16 md:w-24 accent-cute-pink h-2 bg-pink-100 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        {/* Help Button */}
        <button 
          onClick={() => setShowInstructions(true)} 
          className="p-2 bg-white rounded-full shadow-md border-2 border-cute-yellow hover:bg-yellow-50 transition text-cute-yellow active:scale-90 transform"
          title="Hướng dẫn chơi"
        >
          <HelpCircle size={24} />
        </button>

        {/* Settings Button */}
        <button 
          onClick={() => setShowAdmin(true)} 
          className="p-2 bg-white rounded-full shadow-md border-2 border-cute-pink hover:bg-cute-bg transition text-cute-pink active:scale-90 transform"
          title="Cài đặt"
        >
          <Settings size={24} />
        </button>
      </div>

      {/* MAIN CONTENT AREA */}
      <div className="w-full max-w-5xl z-10 relative flex justify-center">
        
        {/* WELCOME SCREEN - Matching Image 1 style */}
        {gameState === 'welcome' && (
          <div className="bg-white p-6 md:p-16 rounded-3xl stamp-border animate-enter max-w-2xl w-full text-center shadow-xl">
             <div className="border-4 border-dashed border-cute-pink-light m-[-10px] rounded-2xl p-6 md:p-8 flex flex-col items-center justify-center h-full">
                <h1 className="text-4xl md:text-6xl font-black text-cute-pink-light tracking-wide uppercase leading-tight mb-8 drop-shadow-sm">
                   Trò Chơi<br/>
                   <span className="text-cute-red">Xé Túi Mù</span>
                </h1>
                
                <button 
                  onClick={handleStartGame}
                  className="px-8 py-3 md:px-10 md:py-3 bg-cute-red text-white text-xl md:text-2xl font-bold rounded-full shadow-lg hover:scale-105 transition-transform duration-300 border-4 border-white ring-2 ring-cute-red active:scale-95"
                >
                  BẮT ĐẦU
                </button>
                
                <div className="mt-4 flex flex-col gap-1 text-sm text-gray-500 font-medium">
                   <span>
                      Chủ đề: <span className="text-cute-blue font-bold">{gameFilter.subject === 'All' ? 'Tất cả' : gameFilter.subject}</span>
                      {' • '}
                      Lớp: <span className="text-cute-pink font-bold">{gameFilter.grade === 'All' ? 'Tất cả' : gameFilter.grade}</span>
                   </span>
                   <button 
                    onClick={() => setShowInstructions(true)}
                    className="text-cute-pink hover:text-cute-red hover:underline font-bold transition flex items-center justify-center gap-1 mt-2"
                  >
                    <HelpCircle size={16}/> Cách chơi
                  </button>
                </div>
             </div>
          </div>
        )}

        {/* SELECTION SCREEN - Matching Image 2 style */}
        {gameState === 'selection' && (
          <div className="w-full animate-enter">
            <div className="bg-white p-4 md:p-8 rounded-3xl stamp-border shadow-2xl relative">
                {/* Title */}
                <div className="text-center mb-6 md:mb-8 mt-8 md:mt-0">
                    <h2 className="text-3xl md:text-5xl font-black text-[#5D4037] inline-block relative">
                       CHỌN 1 TÚI MÙ
                       <SparkleIcon className="absolute -top-4 -right-6 md:-top-6 md:-right-8 w-6 h-6 md:w-8 md:h-8" />
                    </h2>
                </div>

                {/* Grid of bags (Dynamic Rows) */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 justify-items-center">
                  {bagColors.map((color, idx) => {
                    // Check if bag is already opened
                    const isOpened = openedIndices.includes(idx);
                    const isShaking = shakingBagIndex === idx;
                    
                    return (
                      <div key={idx} className={`group w-full max-w-[140px] md:max-w-[160px] transition-all duration-500 ${isOpened ? 'opacity-0 pointer-events-none transform scale-0' : ''}`}>
                        <BlindBagIcon 
                          color={color} 
                          // REMOVED 'transition-transform duration-300' here to let CSS class handle hover
                          className={`w-full h-auto aspect-[1.6/1] ${isShaking ? 'animate-shake-hard' : ''}`}
                          onClick={() => handleBagClick(idx)}
                        />
                      </div>
                    );
                  })}
                </div>
                
                {/* If all bags are opened, show a message or button */}
                {openedIndices.length === bagCount && (
                   <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/95 backdrop-blur-md rounded-3xl z-10 animate-enter">
                      <div className="text-5xl md:text-6xl mb-4 md:mb-6 animate-bounce-slow">🎉</div>
                      <h3 className="text-3xl md:text-4xl font-black text-cute-red mb-4 text-center px-4">Chúc mừng!</h3>
                      <p className="text-lg md:text-xl text-gray-600 mb-8 text-center px-4">Bạn đã mở hết tất cả túi mù.</p>
                      <button 
                        onClick={handleReset}
                        className="px-6 py-3 md:px-10 md:py-4 bg-cute-blue text-white text-lg md:text-xl font-bold rounded-full shadow-xl hover:bg-cute-blue-dark transition active:scale-95 transform flex items-center gap-3"
                      >
                        <RefreshCcw size={24} /> Chơi Lại Từ Đầu
                      </button>
                   </div>
                )}
                
                <button onClick={handleReset} className="absolute top-4 left-4 md:top-6 md:left-6 p-2 text-gray-400 hover:text-gray-600 transition-transform active:scale-90">
                    <ArrowLeft size={28} className="md:w-8 md:h-8" />
                </button>
            </div>
          </div>
        )}

        {/* QUESTION SCREEN - Consistent Style */}
        {gameState === 'question' && currentQuestion && (
          <div className="w-full max-w-3xl animate-enter">
            <div className="bg-white p-2 rounded-3xl stamp-border shadow-xl">
                <div className="bg-cute-bg rounded-2xl p-4 md:p-10 border-2 border-dashed border-cute-pink">
                   <div className="flex justify-center mb-6">
                       <span className="bg-cute-red text-white px-4 py-2 md:px-6 md:py-2 rounded-full font-bold text-lg md:text-xl shadow-md transform -rotate-2 animate-pop">
                           Câu Hỏi
                           {currentQuestion.subject && <span className="ml-2 opacity-80 text-xs md:text-sm bg-white/20 px-2 py-0.5 rounded">
                             {currentQuestion.subject}
                           </span>}
                       </span>
                   </div>
                   
                   <h3 className="text-xl md:text-3xl font-bold text-[#5D4037] text-center mb-8 md:mb-10 leading-relaxed animate-bounce-in">
                     {currentQuestion.text}
                   </h3>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                      {currentQuestion.options.map((opt, idx) => {
                        let btnClass = "bg-white text-gray-600 border-2 border-gray-200"; 
                        if (selectedAnswer !== null) {
                            if (selectedAnswer === idx) {
                                // If this is the button the user clicked
                                if (idx === currentQuestion.correctIndex) {
                                    // And it's correct -> Green
                                    btnClass = "bg-green-100 text-green-700 border-green-400 font-bold";
                                } else {
                                    // And it's wrong -> Red
                                    btnClass = "bg-red-100 text-red-700 border-red-400 font-bold";
                                }
                            } else {
                                // If this is NOT the button the user clicked
                                // Just fade it out. Do NOT reveal the correct answer if the user was wrong.
                                btnClass = "opacity-50 bg-gray-50 border-gray-100";
                            }
                        } else {
                            btnClass += " hover:border-cute-blue hover:text-cute-blue-dark hover:bg-blue-50";
                        }

                        return (
                          <button 
                            key={idx}
                            disabled={selectedAnswer !== null}
                            onClick={() => handleAnswer(idx)}
                            className={`p-4 rounded-xl text-lg font-medium transition-all duration-300 shadow-sm active:scale-95 transform animate-bounce-in ${btnClass}`}
                            style={{ animationDelay: `${idx * 0.1 + 0.1}s`, animationFillMode: 'both' }}
                          >
                             {String.fromCharCode(65 + idx)}. {opt}
                          </button>
                        )
                      })}
                   </div>
                   
                   {/* Feedback area */}
                   <div className="h-8 mt-4 flex justify-center items-center">
                       {selectedAnswer !== null && !isCorrect && (
                           <button 
                                onClick={handleRetryQuestion}
                                className="text-sm font-bold text-gray-500 underline hover:text-gray-800"
                            >
                                Chọn lại
                            </button>
                       )}
                   </div>
                </div>
            </div>
          </div>
        )}

        {/* TEARING ANIMATION */}
        {gameState === 'tearing' && (
          <div className="flex flex-col items-center justify-center animate-drop-in">
             <div className={`relative w-64 h-48 md:w-80 md:h-60 transition-all duration-1000 ${bagAnimation ? 'scale-110' : ''}`}>
                 <div className="absolute inset-0 flex items-center justify-center animate-[wiggle_0.2s_infinite]">
                    <BlindBagIcon 
                        color={currentBagIndex !== null ? bagColors[currentBagIndex] : BagColor.PINK} 
                        className="w-full h-full" 
                    />
                 </div>
                 <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <span className="text-4xl md:text-5xl font-black text-white text-stroke-cute drop-shadow-xl animate-pulse">
                        MỞ QUÀ...
                    </span>
                 </div>
             </div>
          </div>
        )}

        {/* REWARD SCREEN */}
        {gameState === 'reward' && currentPrize && (
          <div className="bg-white p-6 md:p-12 rounded-3xl stamp-border shadow-2xl animate-enter text-center relative max-w-2xl w-full">
             <div className="absolute inset-0 bg-[radial-gradient(circle,rgba(255,244,181,0.5)_0%,transparent_70%)]"></div>
             
             <div className="relative z-10">
                 <h2 className="text-3xl md:text-4xl font-black text-cute-red mb-6 md:mb-8">PHẦN THƯỞNG!</h2>
                 
                 <div className="text-[100px] md:text-[150px] leading-none mb-4 md:mb-6 animate-[bounce_2s_infinite]">
                    {currentPrize.image}
                 </div>
                 <h3 className="text-2xl md:text-3xl font-bold text-[#5D4037] mb-8 md:mb-10">{currentPrize.name}</h3>

                 <div className="flex flex-col sm:flex-row justify-center gap-3 md:gap-4">
                   <button 
                      onClick={handleNextTurn}
                      className="px-6 py-3 bg-cute-blue text-white font-bold rounded-xl shadow-lg hover:bg-cute-blue-dark transition flex items-center justify-center gap-2 active:scale-95 transform"
                   >
                     {openedIndices.length + 1 >= bagCount ? (
                       <>Hoàn thành</>
                     ) : (
                       <><RefreshCcw size={20} /> Mở Túi Khác</>
                     )}
                   </button>
                   <button 
                      onClick={handleReset}
                      className="px-6 py-3 bg-gray-100 text-gray-500 font-bold rounded-xl hover:bg-gray-200 transition active:scale-95 transform"
                   >
                     Trang Chủ
                   </button>
                 </div>
             </div>
          </div>
        )}

      </div>

      {/* Instructions Modal */}
      {showInstructions && (
         <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[60] p-4 animate-enter">
            <div className="bg-white rounded-3xl border-4 border-cute-yellow shadow-2xl w-full max-w-lg overflow-hidden relative">
               <div className="bg-cute-yellow p-4 flex justify-between items-center">
                  <h3 className="text-2xl font-black text-white flex items-center gap-2">
                    <HelpCircle size={28}/> Hướng Dẫn Cách Chơi
                  </h3>
                  <button 
                    onClick={() => setShowInstructions(false)} 
                    className="p-1 bg-white/20 hover:bg-white/40 rounded-full text-white transition"
                  > 
                    <X size={24} /> 
                  </button>
               </div>
               
               <div className="p-6 space-y-6 bg-yellow-50/50">
                  {/* Step 1 */}
                  <div className="flex gap-4 items-start bg-white p-4 rounded-2xl border border-yellow-100 shadow-sm">
                    <div className="bg-cute-yellow w-12 h-12 rounded-full flex items-center justify-center text-white shrink-0 shadow-sm">
                       <MousePointerClick size={24} />
                    </div>
                    <div>
                        <h4 className="font-bold text-gray-800 text-lg mb-1">Bước 1: Chọn Túi</h4>
                        <p className="text-gray-600 text-sm">Chọn một chiếc túi mù xinh xắn bất kỳ mà bạn thích trên màn hình.</p>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="flex gap-4 items-start bg-white p-4 rounded-2xl border border-yellow-100 shadow-sm">
                    <div className="bg-cute-blue w-12 h-12 rounded-full flex items-center justify-center text-white shrink-0 shadow-sm">
                       <MessageCircleQuestion size={24} />
                    </div>
                    <div>
                        <h4 className="font-bold text-gray-800 text-lg mb-1">Bước 2: Trả Lời Câu Hỏi</h4>
                        <p className="text-gray-600 text-sm">Một câu hỏi thử thách sẽ hiện ra. Hãy chọn đáp án đúng để được mở túi nhé!</p>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className="flex gap-4 items-start bg-white p-4 rounded-2xl border border-yellow-100 shadow-sm">
                    <div className="bg-cute-pink w-12 h-12 rounded-full flex items-center justify-center text-white shrink-0 shadow-sm">
                       <Gift size={24} />
                    </div>
                    <div>
                        <h4 className="font-bold text-gray-800 text-lg mb-1">Bước 3: Nhận Quà</h4>
                        <p className="text-gray-600 text-sm">Nếu trả lời đúng, túi sẽ mở ra và bạn sẽ nhận được một phần quà bất ngờ!</p>
                    </div>
                  </div>
                  
                  <div className="text-center pt-2">
                     <button 
                       onClick={() => setShowInstructions(false)}
                       className="px-8 py-2 bg-cute-yellow text-white font-bold rounded-xl hover:bg-yellow-400 transition shadow-md active:scale-95"
                     >
                       Đã Hiểu!
                     </button>
                  </div>
               </div>
            </div>
         </div>
      )}

      {/* Admin Panel Overlay */}
      {showAdmin && (
        <AdminPanel 
          questions={questions} 
          onUpdateQuestions={setQuestions}
          onUpdateBgm={handleUpdateBgm}
          bagCount={bagCount}
          onUpdateBagCount={handleUpdateBagCount}
          gameFilter={gameFilter}
          onUpdateGameFilter={setGameFilter}
          flipDirection={flipDirection}
          onUpdateFlipDirection={setFlipDirection}
          rotationAngle={rotationAngle}
          onUpdateRotationAngle={setRotationAngle}
          onClose={() => setShowAdmin(false)} 
          onStartGame={handleStartGameFromAdmin}
        />
      )}
    </div>
  );
};

export default App;