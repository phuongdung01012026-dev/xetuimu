import React from 'react';
import { BagColor } from '../types';

interface IconProps {
  className?: string;
  style?: React.CSSProperties;
  onClick?: () => void;
}

interface BlindBagIconProps extends IconProps {
  color: BagColor;
}

export const BlindBagIcon: React.FC<BlindBagIconProps> = ({ color, className, onClick, style }) => {
  let mainColor = '';
  let shadowColor = '';

  switch (color) {
    case BagColor.PINK:
      mainColor = '#FF9EAA'; // Coral Pink
      shadowColor = '#FF7A8A';
      break;
    case BagColor.BLUE:
      mainColor = '#89CFF0'; // Baby Blue
      shadowColor = '#6BBBE0';
      break;
    case BagColor.YELLOW:
      mainColor = '#FAD02E'; // Mustard Yellow
      shadowColor = '#E0B810';
      break;
    case BagColor.GREEN:
      mainColor = '#A8D8B9'; // Pastel Green
      shadowColor = '#8BC6A0';
      break;
  }

  // Added 'hover-3d-flip' class for the new effect
  return (
    <div 
      className={`relative cursor-pointer hover-3d-flip ${className}`}
      onClick={onClick}
      style={style}
    >
      <svg viewBox="0 0 140 80" className="w-full h-full drop-shadow-md">
        {/* Candy Wrapper Body - Main Rectangle */}
        <rect x="15" y="5" width="110" height="70" rx="4" fill={mainColor} />
        
        {/* Left Zigzag (Crimped Edge) */}
        <path d="M15,5 L5,5 L5,75 L15,75 Z" fill={mainColor} />
        <path d="M5,5 L0,0 M5,10 L0,10 M5,20 L0,20 M5,30 L0,30 M5,40 L0,40 M5,50 L0,50 M5,60 L0,60 M5,70 L0,70 M5,75 L0,80" 
              stroke={shadowColor} strokeWidth="1" fill="none" opacity="0.5" />

        {/* Right Zigzag (Crimped Edge) */}
        <path d="M125,5 L135,5 L135,75 L125,75 Z" fill={mainColor} />
        
        {/* Shading/Gradient effect */}
        <path d="M15,5 Q70,20 125,5 V75 Q70,60 15,75 Z" fill="white" opacity="0.1" />

        {/* Center Heart */}
        <path 
          d="M70,55 C60,55 55,45 55,38 C55,30 62,25 68,32 L70,34 L72,32 C78,25 85,30 85,38 C85,45 80,55 70,55 Z" 
          fill="white" 
          stroke={shadowColor} 
          strokeWidth="2"
          strokeLinejoin="round"
        />
        
        {/* Shine on heart */}
        <path d="M78,32 Q82,32 82,36" stroke={shadowColor} strokeWidth="2" strokeLinecap="round" opacity="0.5" />
      </svg>
    </div>
  );
};

export const FlowerIcon: React.FC<IconProps & { color?: string }> = ({ className, style, color = '#FF6B6B' }) => (
  <svg viewBox="0 0 100 100" className={className} style={style}>
    <path d="M50 35 C50 20 35 20 35 35 C20 35 20 50 35 50 C20 50 20 65 35 65 C35 80 50 80 50 65 C50 80 65 80 65 65 C80 65 80 50 65 50 C80 50 80 35 65 35 C65 20 50 20 50 35 Z" fill={color} />
    <circle cx="50" cy="50" r="10" fill="white" />
  </svg>
);

export const SparkleIcon: React.FC<IconProps> = ({ className, style }) => (
  <svg viewBox="0 0 100 100" className={className} style={style}>
    <path d="M50 0 C50 30 70 50 100 50 C70 50 50 70 50 100 C50 70 30 50 0 50 C30 50 50 30 50 0 Z" fill="white" stroke="#6BBBE0" strokeWidth="2" />
  </svg>
);