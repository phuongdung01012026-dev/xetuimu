import React, { useState } from 'react';
import { Question, SUBJECTS, GRADES, GameFilter } from '../types';
import { Plus, Trash2, Edit2, Save, X, Music, Upload, RotateCcw, FileSpreadsheet, Download, Sparkles, Loader, Gamepad2, Filter, Database, FileJson, Trash, List, LayoutGrid, Play } from 'lucide-react';
import { read, utils, writeFile } from 'xlsx';
import { GoogleGenAI, Type } from "@google/genai";

interface AdminPanelProps {
  questions: Question[];
  onUpdateQuestions: (questions: Question[]) => void;
  onUpdateBgm: (bgmUrl: string | null) => void;
  bagCount: number;
  onUpdateBagCount: (count: number) => void;
  gameFilter: GameFilter;
  onUpdateGameFilter: (filter: GameFilter) => void;
  flipDirection: 'left' | 'right' | 'up' | 'down';
  onUpdateFlipDirection: (dir: 'left' | 'right' | 'up' | 'down') => void;
  rotationAngle: number;
  onUpdateRotationAngle: (angle: number) => void;
  onClose: () => void;
  onStartGame: () => void;
}

type TabType = 'general' | 'library' | 'data' | 'music';
const AI_STYLES = ["Cơ bản", "Nâng cao", "Vui nhộn", "Đố mẹo", "Thực tế"];

export const AdminPanel: React.FC<AdminPanelProps> = ({ 
  questions, 
  onUpdateQuestions, 
  onUpdateBgm, 
  bagCount, 
  onUpdateBagCount, 
  gameFilter,
  onUpdateGameFilter,
  flipDirection,
  onUpdateFlipDirection,
  rotationAngle,
  onUpdateRotationAngle,
  onClose,
  onStartGame
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('library'); // Default to library since user is focusing on it
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Question>({
    id: '',
    text: '',
    options: ['', '', '', ''],
    correctIndex: 0,
    subject: SUBJECTS[0],
    grade: GRADES[0]
  });

  // Library View Filter State
  const [libFilterSubject, setLibFilterSubject] = useState<string>('All');
  const [libFilterGrade, setLibFilterGrade] = useState<string>('All');

  // AI Generation State
  const [showAiModal, setShowAiModal] = useState(false);
  const [aiPrompt, setAiPrompt] = useState("");
  const [aiSubject, setAiSubject] = useState(SUBJECTS[0]);
  const [aiGrade, setAiGrade] = useState(GRADES[0]);
  const [aiStyle, setAiStyle] = useState(AI_STYLES[0]);
  const [isGenerating, setIsGenerating] = useState(false);

  // --- HELPER FUNCTIONS ---

  const handleOpenAiModal = () => {
      setAiSubject(libFilterSubject !== 'All' ? libFilterSubject : SUBJECTS[0]);
      setAiGrade(libFilterGrade !== 'All' ? libFilterGrade : GRADES[0]);
      setShowAiModal(true);
  };

  const handleEdit = (q: Question) => {
    setEditingId(q.id);
    setEditForm({ 
        ...q, 
        subject: q.subject || SUBJECTS[0],
        grade: q.grade || GRADES[0]
    });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditForm({ id: '', text: '', options: ['', '', '', ''], correctIndex: 0, subject: SUBJECTS[0], grade: GRADES[0] });
  };

  const handleSave = () => {
    if (!editForm.text.trim()) return alert("Vui lòng nhập câu hỏi");
    if (editForm.options.some(o => !o.trim())) return alert("Vui lòng nhập đủ 4 đáp án");

    if (editingId === 'new') {
      onUpdateQuestions([...questions, { ...editForm, id: Date.now().toString() }]);
    } else {
      onUpdateQuestions(questions.map(q => q.id === editingId ? editForm : q));
    }
    handleCancelEdit();
  };

  const handleDelete = (id: string) => {
    if (window.confirm("Bạn có chắc muốn xóa câu hỏi này không?")) {
      onUpdateQuestions(questions.filter(q => q.id !== id));
    }
  };

  const startNew = () => {
    setEditingId('new');
    setEditForm({
      id: 'new',
      text: '',
      options: ['', '', '', ''],
      correctIndex: 0,
      subject: libFilterSubject !== 'All' ? libFilterSubject : SUBJECTS[0],
      grade: libFilterGrade !== 'All' ? libFilterGrade : GRADES[0]
    });
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 3 * 1024 * 1024) { 
        alert("File nhạc quá lớn! Vui lòng chọn file dưới 3MB.");
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        onUpdateBgm(e.target?.result as string);
        alert("Đã cập nhật nhạc nền thành công!");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleResetBgm = () => {
    if (window.confirm("Bạn muốn quay về nhạc mặc định?")) {
      onUpdateBgm(null);
    }
  };

  const handleExportJSON = () => {
    const dataStr = JSON.stringify(questions, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = `system_backup_${new Date().toISOString().slice(0,10)}.json`;
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleImportJSON = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const parsed = JSON.parse(e.target?.result as string);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].text) {
           const choice = window.confirm(`Tìm thấy ${parsed.length} câu hỏi.\nOK: THAY THẾ toàn bộ.\nCANCEL: GỘP THÊM vào danh sách.`);
           if (choice) onUpdateQuestions(parsed);
           else {
               const merged = parsed.map((q: any) => ({...q, id: Date.now() + Math.random().toString()}));
               onUpdateQuestions([...questions, ...merged]);
           }
           alert("Khôi phục dữ liệu thành công!");
        } else {
            alert("File không hợp lệ.");
        }
      } catch (error) {
        alert("Lỗi khi đọc file JSON.");
      }
      event.target.value = "";
    };
    reader.readAsText(file);
  };

  const handleExportExcel = (isTemplate: boolean = false) => {
     const wsData = [["Câu hỏi", "Đáp án A", "Đáp án B", "Đáp án C", "Đáp án D", "Đáp án đúng (A/B/C/D)", "Môn Học", "Lớp"]];
     if (isTemplate) {
        wsData.push(["1 + 1 bằng mấy?", "1", "2", "3", "4", "B", "Toán", "Lớp 1"]);
     } else {
        questions.forEach(q => {
            const correctChar = String.fromCharCode(65 + q.correctIndex);
            wsData.push([q.text, q.options[0], q.options[1], q.options[2], q.options[3], correctChar, q.subject || "", q.grade || ""]);
        });
     }
     const ws = utils.aoa_to_sheet(wsData);
     const wb = utils.book_new();
     utils.book_append_sheet(wb, ws, "Danh Sach Cau Hoi");
     writeFile(wb, isTemplate ? "mau_cau_hoi.xlsx" : `danh_sach_cau_hoi_${new Date().toISOString().slice(0,10)}.xlsx`);
  };

  const handleExcelUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = read(data, { type: 'array' });
        const jsonData: any[][] = utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]], { header: 1 });
        const rows = jsonData.slice(1);
        const newQuestions: Question[] = [];

        rows.forEach((row) => {
          if (row.length >= 6 && row[0]) {
            let correctIndex = 0;
            const char = String(row[5] || "").trim().toUpperCase();
            if (char === 'B') correctIndex = 1;
            else if (char === 'C') correctIndex = 2;
            else if (char === 'D') correctIndex = 3;
            else { const n = parseInt(char); if (!isNaN(n) && n>=1 && n<=4) correctIndex = n-1; }

            newQuestions.push({
                 id: Date.now() + Math.random().toString(),
                 text: String(row[0]).trim(),
                 options: [String(row[1]||""), String(row[2]||""), String(row[3]||""), String(row[4]||"")],
                 correctIndex,
                 subject: String(row[6] || "Khác").trim(),
                 grade: String(row[7] || "Khác").trim()
            });
          }
        });

        if (newQuestions.length > 0 && window.confirm(`Tìm thấy ${newQuestions.length} câu hỏi. Thêm vào danh sách?`)) {
             onUpdateQuestions([...questions, ...newQuestions]);
             alert("Nhập dữ liệu thành công!");
        }
      } catch (error) { alert("Lỗi đọc file Excel."); }
      event.target.value = "";
    };
    reader.readAsArrayBuffer(file);
  };

  const handleClearAllData = () => {
    if (window.confirm("CẢNH BÁO: Xóa HẾT câu hỏi? Không thể hoàn tác!") && window.confirm("Xác nhận lần 2?")) {
        onUpdateQuestions([]);
    }
  };

  const handleGenerateAi = async () => {
    if (!aiPrompt.trim()) return;
    setIsGenerating(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Tạo 5 câu hỏi trắc nghiệm (4 đáp án) cho trẻ em VN. 
                      Chủ đề cụ thể: "${aiPrompt}". 
                      Môn học: ${aiSubject}. 
                      Lớp/Trình độ: ${aiGrade}.
                      Dạng câu hỏi/Phong cách: ${aiStyle}.
                      Nội dung phải chính xác, giáo dục và phù hợp với lứa tuổi.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                text: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctIndex: { type: Type.INTEGER },
                subject: { type: Type.STRING },
                grade: { type: Type.STRING }
              },
              required: ["text", "options", "correctIndex"]
            }
          }
        }
      });
      const generatedData = JSON.parse(response.text || "[]");
      if (Array.isArray(generatedData) && generatedData.length > 0) {
         const newQs = generatedData.map((q: any) => ({
             id: Date.now().toString() + Math.random().toString(),
             ...q,
             subject: q.subject || aiSubject,
             grade: q.grade || aiGrade
         }));
         onUpdateQuestions([...questions, ...newQs]);
         setShowAiModal(false); setAiPrompt("");
         alert(`Đã thêm ${newQs.length} câu hỏi.`);
      } else alert("AI lỗi hoặc không trả về kết quả.");
    } catch (e: any) { alert("Lỗi AI: " + e.message); } 
    finally { setIsGenerating(false); }
  };

  const displayedQuestions = questions.filter(q => {
     return (libFilterSubject === 'All' || q.subject === libFilterSubject) && 
            (libFilterGrade === 'All' || q.grade === libFilterGrade);
  });

  // --- RENDER COMPONENTS ---

  const MenuButton = ({ id, label, icon: Icon }: { id: TabType, label: string, icon: any }) => (
    <button 
      onClick={() => setActiveTab(id)}
      className={`w-full flex items-center gap-3 px-4 py-4 transition-all duration-200 text-left font-bold ${
        activeTab === id 
          ? 'bg-white text-cute-blue border-l-4 border-cute-blue shadow-sm' 
          : 'text-gray-500 hover:bg-white/50 hover:text-gray-700'
      }`}
    >
      <Icon size={20} />
      <span className="hidden md:inline">{label}</span>
    </button>
  );

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-0 md:p-4">
      {/* AI Modal */}
      {showAiModal && (
        <div className="absolute inset-0 z-[60] flex items-center justify-center bg-black/20 backdrop-blur-[2px]">
          <div className="bg-white p-6 rounded-2xl shadow-2xl w-full max-w-lg border-4 border-purple-300 animate-pop">
            <h3 className="text-xl font-bold text-purple-600 mb-4 flex items-center gap-2"><Sparkles size={24} /> Tạo Câu Hỏi AI</h3>
            
            <div className="space-y-4 mb-6">
                <div>
                   <label className="block text-xs font-bold text-gray-500 mb-1">Chủ đề (VD: Động vật biển, Phép cộng...)</label>
                   <input type="text" value={aiPrompt} onChange={(e) => setAiPrompt(e.target.value)} placeholder="Nhập chủ đề..." className="w-full p-3 border border-purple-200 rounded-xl bg-purple-50 outline-none focus:ring-2 focus:ring-purple-400" onKeyDown={(e)=>e.key==='Enter'&&handleGenerateAi()}/>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                   <div>
                       <label className="block text-xs font-bold text-gray-500 mb-1">Môn Học</label>
                       <select value={aiSubject} onChange={(e) => setAiSubject(e.target.value)} className="w-full p-2 rounded-lg border border-purple-200 bg-white text-sm outline-none">
                          {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                       </select>
                   </div>
                   <div>
                       <label className="block text-xs font-bold text-gray-500 mb-1">Lớp</label>
                       <select value={aiGrade} onChange={(e) => setAiGrade(e.target.value)} className="w-full p-2 rounded-lg border border-purple-200 bg-white text-sm outline-none">
                          {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
                       </select>
                   </div>
                   <div className="col-span-2 md:col-span-1">
                       <label className="block text-xs font-bold text-gray-500 mb-1">Dạng Câu Hỏi</label>
                       <select value={aiStyle} onChange={(e) => setAiStyle(e.target.value)} className="w-full p-2 rounded-lg border border-purple-200 bg-white text-sm outline-none">
                          {AI_STYLES.map(s => <option key={s} value={s}>{s}</option>)}
                       </select>
                   </div>
                </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
               <button onClick={() => setShowAiModal(false)} className="px-4 py-2 text-gray-500 hover:bg-gray-100 rounded-lg font-bold text-sm">Hủy</button>
               <button onClick={handleGenerateAi} disabled={isGenerating || !aiPrompt.trim()} className="px-6 py-2 bg-purple-500 text-white font-bold rounded-lg shadow flex items-center gap-2 hover:bg-purple-600 transition disabled:opacity-50">
                 {isGenerating ? <Loader className="animate-spin" size={18}/> : <Sparkles size={18}/>} Tạo Ngay
               </button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white md:rounded-3xl shadow-2xl w-full max-w-5xl h-[100dvh] md:h-[85vh] flex flex-col overflow-hidden md:border-4 border-cute-blue animate-pop">
        
        {/* Header Bar */}
        <div className="bg-cute-blue p-4 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3 text-white">
             <div className="bg-white/20 p-2 rounded-xl"><Gamepad2 size={24} /></div>
             <div>
                <h2 className="text-xl font-bold font-rounded">Cô Dung Tin Học</h2>
                <p className="text-xs text-blue-100 opacity-90">Cài đặt trò chơi & nội dung</p>
             </div>
          </div>
          <div className="flex items-center gap-3">
            {/* Start Game Button */}
            <button 
                onClick={onStartGame}
                className="px-4 py-2 bg-cute-green text-white rounded-xl font-bold hover:bg-green-500 transition shadow-md border-2 border-white/30 flex items-center gap-2 active:scale-95"
            >
                <Play size={20} fill="currentColor" /> 
                <span className="hidden sm:inline">Lưu & Vào Game</span>
                <span className="sm:hidden">Chơi</span>
            </button>

            <button onClick={onClose} className="p-2 bg-white/20 hover:bg-white/40 rounded-full text-white transition hover:rotate-90">
                <X size={24} />
            </button>
          </div>
        </div>

        {/* Main Body */}
        <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
          
          {/* Sidebar Menu */}
          <div className="w-full md:w-64 bg-gray-50 border-b md:border-b-0 md:border-r border-gray-200 flex flex-row md:flex-col shrink-0 overflow-x-auto md:overflow-visible">
            <MenuButton id="general" label="Cài Đặt Chung" icon={LayoutGrid} />
            <MenuButton id="library" label="Thư Viện Câu Hỏi" icon={List} />
            <MenuButton id="data" label="Sao Lưu & Dữ Liệu" icon={Database} />
            <MenuButton id="music" label="Nhạc Nền" icon={Music} />
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-white relative">
            
            {/* --- TAB: GENERAL SETTINGS --- */}
            {activeTab === 'general' && (
              <div className="space-y-6 animate-pop">
                <div className="flex items-center gap-2 mb-2 pb-2 border-b">
                   <h3 className="text-2xl font-bold text-gray-800">Cấu Hình Trò Chơi</h3>
                </div>

                <div className="bg-green-50 p-6 rounded-2xl border border-green-100">
                    <label className="block font-bold text-gray-700 mb-3 text-lg">Số Lượng Túi Mù</label>
                    <div className="flex flex-wrap items-center gap-4">
                        <input type="number" min="1" max="50" value={bagCount} onChange={(e) => onUpdateBagCount(Math.min(50, Math.max(1, parseInt(e.target.value)||1)))} className="w-24 p-3 border-2 border-cute-green rounded-xl text-center font-bold text-2xl text-cute-green outline-none bg-white"/>
                        <div className="flex gap-2">
                           {[4, 6, 8, 12, 16].map(num => (
                             <button key={num} onClick={() => onUpdateBagCount(num)} className={`w-10 h-10 rounded-lg font-bold transition ${bagCount === num ? 'bg-cute-green text-white scale-110 shadow' : 'bg-white border hover:bg-green-50'}`}>{num}</button>
                           ))}
                        </div>
                    </div>
                </div>

                <div className="bg-purple-50 p-6 rounded-2xl border border-purple-100">
                    <label className="block font-bold text-gray-700 mb-3 text-lg">Bộ Lọc Trò Chơi (Đang Chơi)</label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <span className="text-xs font-bold text-gray-500 uppercase">Môn Học</span>
                            <select value={gameFilter.subject} onChange={(e) => onUpdateGameFilter({...gameFilter, subject: e.target.value})} className="w-full p-3 mt-1 rounded-xl border-2 border-purple-200 outline-none font-medium">
                                <option value="All">Tất cả môn học</option>
                                {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>
                        <div>
                            <span className="text-xs font-bold text-gray-500 uppercase">Trình Độ</span>
                            <select value={gameFilter.grade} onChange={(e) => onUpdateGameFilter({...gameFilter, grade: e.target.value})} className="w-full p-3 mt-1 rounded-xl border-2 border-purple-200 outline-none font-medium">
                                <option value="All">Tất cả các lớp</option>
                                {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
                            </select>
                        </div>
                    </div>
                    <p className="mt-3 text-sm text-purple-600">Chỉ những câu hỏi khớp với bộ lọc này mới xuất hiện khi chơi.</p>
                </div>

                <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100">
                    <label className="block font-bold text-gray-700 mb-3 text-lg">Hiệu Ứng Lật 3D Túi Mù</label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <span className="text-xs font-bold text-gray-500 uppercase">Hướng Lật</span>
                            <select value={flipDirection} onChange={(e) => onUpdateFlipDirection(e.target.value as any)} className="w-full p-3 mt-1 rounded-xl border-2 border-blue-200 outline-none font-medium">
                                <option value="left">Trái</option>
                                <option value="right">Phải</option>
                                <option value="up">Lên</option>
                                <option value="down">Xuống</option>
                            </select>
                        </div>
                        <div>
                            <span className="text-xs font-bold text-gray-500 uppercase">Góc Xoay (Độ)</span>
                            <select value={rotationAngle} onChange={(e) => onUpdateRotationAngle(parseInt(e.target.value, 10))} className="w-full p-3 mt-1 rounded-xl border-2 border-blue-200 outline-none font-medium">
                                <option value="15">15°</option>
                                <option value="30">30°</option>
                                <option value="45">45°</option>
                                <option value="60">60°</option>
                            </select>
                        </div>
                    </div>
                    <p className="mt-3 text-sm text-blue-600">Tùy chỉnh hiệu ứng khi rê chuột vào túi mù trên màn hình chọn.</p>
                </div>
              </div>
            )}

            {/* --- TAB: QUESTION LIBRARY --- */}
            {activeTab === 'library' && (
              <div className="space-y-4 h-full flex flex-col animate-pop">
                 <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-4 border-b">
                     <div>
                        <h3 className="text-2xl font-bold text-gray-800">Thư Viện Câu Hỏi</h3>
                        <p className="text-sm text-gray-500">Tổng: {questions.length} câu | Hiển thị: {displayedQuestions.length}</p>
                     </div>
                     <div className="flex flex-wrap gap-2">
                        <button onClick={() => handleExportExcel(true)} className="px-3 py-2 border border-gray-300 text-gray-600 rounded-lg font-bold text-sm hover:bg-gray-50 flex items-center gap-1 transition" title="Tải file mẫu Excel">
                           <Download size={16}/> Mẫu
                        </button>
                        <label className="px-3 py-2 bg-green-100 text-green-700 rounded-lg font-bold text-sm hover:bg-green-200 flex items-center gap-1 cursor-pointer transition">
                           <FileSpreadsheet size={16}/> Nhập Excel
                           <input type="file" accept=".xlsx, .xls" onChange={handleExcelUpload} className="hidden" />
                        </label>
                        <button onClick={handleOpenAiModal} className="px-3 py-2 bg-purple-100 text-purple-600 rounded-lg font-bold text-sm hover:bg-purple-200 flex items-center gap-1 transition"><Sparkles size={16}/> Tạo AI</button>
                        <button onClick={startNew} disabled={editingId !== null} className="px-3 py-2 bg-cute-blue text-white rounded-lg font-bold text-sm hover:bg-cute-blue-dark shadow flex items-center gap-1 transition"><Plus size={16}/> Thêm Thủ Công</button>
                     </div>
                 </div>

                 {/* Filters */}
                 <div className="bg-gray-50 p-3 rounded-xl flex flex-wrap gap-4 items-center">
                    <div className="flex items-center gap-2 text-gray-500 font-bold text-sm"><Filter size={16} /> Lọc danh sách:</div>
                    <select value={libFilterSubject} onChange={(e) => setLibFilterSubject(e.target.value)} className="px-3 py-1.5 rounded-lg border text-sm outline-none">
                        <option value="All">Tất cả Môn</option>
                        {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                    <select value={libFilterGrade} onChange={(e) => setLibFilterGrade(e.target.value)} className="px-3 py-1.5 rounded-lg border text-sm outline-none">
                        <option value="All">Tất cả Lớp</option>
                        {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
                    </select>
                 </div>

                 {/* Editor */}
                 {editingId === 'new' && (
                    <div className="bg-white p-6 rounded-2xl border-2 border-cute-green shadow-lg mb-4">
                      <h3 className="text-lg font-bold text-cute-green-dark mb-4">Thêm Câu Hỏi Mới</h3>
                      <Editor form={editForm} setForm={setEditForm} onSave={handleSave} onCancel={handleCancelEdit} />
                    </div>
                 )}

                 {/* List */}
                 <div className="flex-1 overflow-y-auto space-y-3 pr-2">
                    {displayedQuestions.length === 0 ? (
                        <div className="text-center py-10 text-gray-400 border-2 border-dashed rounded-xl">Chưa có câu hỏi nào.</div>
                    ) : (
                        displayedQuestions.map((q) => (
                           <div key={q.id} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition">
                             {editingId === q.id ? (
                               <Editor form={editForm} setForm={setEditForm} onSave={handleSave} onCancel={handleCancelEdit} />
                             ) : (
                               <div className="flex gap-4">
                                  <div className="flex-1">
                                     <div className="flex gap-2 mb-1">
                                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-500 border border-blue-100">{q.subject}</span>
                                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-gray-100 text-gray-500 border border-gray-200">{q.grade}</span>
                                     </div>
                                     <h4 className="font-bold text-gray-800 mb-2">{q.text}</h4>
                                     <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-600">
                                        {q.options.map((o, i) => (
                                            <div key={i} className={`px-2 py-1 rounded border ${i===q.correctIndex ? 'bg-green-50 border-green-200 text-green-700 font-bold' : 'bg-gray-50 border-gray-100'}`}>
                                                {String.fromCharCode(65+i)}. {o}
                                            </div>
                                        ))}
                                     </div>
                                  </div>
                                  <div className="flex flex-col gap-1">
                                     <button onClick={() => handleEdit(q)} className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg"><Edit2 size={18} /></button>
                                     <button onClick={() => handleDelete(q.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg"><Trash2 size={18} /></button>
                                  </div>
                               </div>
                             )}
                           </div>
                        ))
                    )}
                 </div>
              </div>
            )}

            {/* --- TAB: DATA MANAGEMENT --- */}
            {activeTab === 'data' && (
              <div className="space-y-6 animate-pop">
                 <div className="border-b pb-4">
                    <h3 className="text-2xl font-bold text-gray-800">Quản Lý Dữ Liệu</h3>
                    <p className="text-gray-500">Sao lưu, khôi phục hoặc xóa toàn bộ hệ thống.</p>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100">
                        <h4 className="font-bold text-blue-800 mb-4 flex items-center gap-2"><Download size={20}/> Xuất Dữ Liệu</h4>
                        <div className="space-y-3">
                            <button onClick={handleExportJSON} className="w-full py-3 bg-white border border-blue-200 text-blue-600 rounded-xl font-bold hover:bg-blue-100 flex items-center justify-center gap-2">
                                <FileJson size={18}/> Backup JSON (Full)
                            </button>
                            <button onClick={() => handleExportExcel(false)} className="w-full py-3 bg-white border border-green-200 text-green-600 rounded-xl font-bold hover:bg-green-50 flex items-center justify-center gap-2">
                                <FileSpreadsheet size={18}/> Xuất Excel
                            </button>
                        </div>
                    </div>

                    <div className="bg-orange-50 p-6 rounded-2xl border border-orange-100">
                        <h4 className="font-bold text-orange-800 mb-4 flex items-center gap-2"><Upload size={20}/> Nhập / Xóa</h4>
                        <div className="space-y-3">
                            <label className="w-full py-3 bg-white border border-blue-200 text-blue-600 rounded-xl font-bold hover:bg-blue-100 flex items-center justify-center gap-2 cursor-pointer">
                                <FileJson size={18}/> Khôi Phục JSON
                                <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
                            </label>
                            <button onClick={handleClearAllData} className="w-full py-3 bg-red-100 text-red-600 border border-red-200 rounded-xl font-bold hover:bg-red-200 flex items-center justify-center gap-2 mt-4">
                                <Trash size={18}/> Xóa Toàn Bộ Dữ Liệu
                            </button>
                        </div>
                    </div>
                 </div>
              </div>
            )}

            {/* --- TAB: MUSIC --- */}
            {activeTab === 'music' && (
              <div className="space-y-6 animate-pop">
                 <div className="border-b pb-4">
                    <h3 className="text-2xl font-bold text-gray-800">Cài Đặt Nhạc Nền</h3>
                 </div>
                 <div className="bg-pink-50 p-8 rounded-2xl border border-pink-100 flex flex-col items-center justify-center gap-6">
                    <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-md text-cute-pink">
                        <Music size={40} />
                    </div>
                    <div className="text-center">
                        <p className="font-bold text-gray-700">File nhạc hiện tại</p>
                        <p className="text-sm text-gray-500">Được lưu trong trình duyệt của bạn</p>
                    </div>
                    <div className="flex gap-4">
                        <label className="px-6 py-3 bg-white border-2 border-cute-pink text-cute-pink rounded-xl font-bold hover:bg-pink-100 cursor-pointer flex items-center gap-2">
                           <Upload size={20} /> Tải Nhạc Mới (MP3)
                           <input type="file" accept="audio/*" onChange={handleFileUpload} className="hidden" />
                        </label>
                        <button onClick={handleResetBgm} className="px-6 py-3 bg-gray-200 text-gray-600 rounded-xl font-bold hover:bg-gray-300 flex items-center gap-2">
                           <RotateCcw size={20} /> Mặc Định
                        </button>
                    </div>
                    <p className="text-xs text-gray-400 max-w-xs text-center">Lưu ý: File nhạc tối đa 3MB để đảm bảo hiệu suất tốt nhất.</p>
                 </div>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
};

const Editor = ({ form, setForm, onSave, onCancel }: { 
  form: Question, 
  setForm: (f: Question) => void,
  onSave: () => void,
  onCancel: () => void
}) => {
  return (
    <div className="space-y-4 w-full animate-pop">
      <div className="flex gap-4">
          <div className="flex-1">
              <label className="block text-xs font-bold text-gray-500 mb-1">Môn Học</label>
              <select value={form.subject || SUBJECTS[0]} onChange={(e) => setForm({...form, subject: e.target.value})} className="w-full p-2 border border-gray-300 rounded-lg outline-none">
                  {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
          </div>
          <div className="flex-1">
              <label className="block text-xs font-bold text-gray-500 mb-1">Lớp</label>
              <select value={form.grade || GRADES[0]} onChange={(e) => setForm({...form, grade: e.target.value})} className="w-full p-2 border border-gray-300 rounded-lg outline-none">
                  {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
          </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Nội dung câu hỏi</label>
        <textarea value={form.text} onChange={(e) => setForm({...form, text: e.target.value})} className="w-full p-3 border border-gray-300 rounded-xl outline-none focus:border-cute-blue" rows={2} placeholder="Nhập câu hỏi..."/>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {form.options.map((opt, i) => (
          <div key={i}>
             <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-bold text-gray-500">Đáp án {String.fromCharCode(65 + i)}</label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="correctIndex" checked={form.correctIndex === i} onChange={() => setForm({...form, correctIndex: i})} className="accent-green-500"/>
                  <span className={`text-xs ${form.correctIndex === i ? 'text-green-600 font-bold' : 'text-gray-400'}`}>Đúng</span>
                </label>
             </div>
             <input type="text" value={opt} onChange={(e) => { const newOpts = [...form.options]; newOpts[i] = e.target.value; setForm({...form, options: newOpts}); }} className={`w-full p-2 border rounded-lg outline-none ${form.correctIndex === i ? 'border-green-300 bg-green-50' : 'border-gray-300'}`} placeholder={`Đáp án ${i + 1}`}/>
          </div>
        ))}
      </div>

      <div className="flex justify-end gap-2 mt-4 pt-4 border-t border-gray-100">
        <button onClick={onCancel} className="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium">Hủy</button>
        <button onClick={onSave} className="px-6 py-2 text-white bg-green-500 hover:bg-green-600 rounded-lg font-bold shadow-md">Lưu Lại</button>
      </div>
    </div>
  )
}